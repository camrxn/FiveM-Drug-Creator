Config = {
    Consumables = {},
    Zones = {},
    Webhooks = {
        DrugActions = "https://discord.com/api/webhooks/1364450964827930705/A25Jb46Ijh3NEJW18drdWgqjKMlpHYeTtzq_bXF5oeIEWh8sy2loXSPPfoeNQrFoYXC8" -- replace this with your actual Discord webhook
    }
}